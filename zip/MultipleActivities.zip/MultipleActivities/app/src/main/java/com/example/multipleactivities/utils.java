package com.example.multipleactivities;

import android.widget.Toast;

public class utils {

}
